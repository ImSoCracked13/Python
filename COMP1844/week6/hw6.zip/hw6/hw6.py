import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load the dataset
file_path = 'E:/Work/Studies/Coding/Python/COMP1844/week6/winequality-red.csv'
data = pd.read_csv(file_path, delimiter=';')

# Task A: Create a new dataset with the specified records
first_three = data.head(3)
last_two = data.tail(2)
max_density = data[data['density'] == data['density'].max()]

# Combine these records into a new dataset and remove duplicates
combined_data = pd.concat([first_three, last_two, max_density]).drop_duplicates()

# Task B: Select specific columns
columns_of_interest = ["volatile acidity", "free sulfur dioxide", "total sulfur dioxide", "pH", "alcohol"]
filtered_data = combined_data[columns_of_interest]

# Task C: Save the new dataset to a CSV file
output_path = 'E:/Work/Studies/Coding/Python/COMP1844/daya6_redWine_dataset.csv'
filtered_data.to_csv(output_path, index=False)

# Task D & E: Plot the dataset as a heatmap with proper labels
plt.figure(figsize=(10, 6))
heatmap = sns.heatmap(filtered_data, annot=True, cmap='viridis')

# Add proper labels
heatmap.set_title('Heatmap of Selected Wine Quality Features')
heatmap.set_xlabel('Features')
heatmap.set_ylabel('Records')

# Show the plot
plt.show()
